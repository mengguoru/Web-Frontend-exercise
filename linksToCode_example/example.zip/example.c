#include <stdio.h>
int int main(int argc, char const *argv[])
{
	printf("Hello,world\n");
	return 0;
}